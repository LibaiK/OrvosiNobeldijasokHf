/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package OrvosiNobeldijasokGUI;

import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import static javax.swing.JOptionPane.showMessageDialog;

public class FXMLDocumentController implements Initializable {
    
    @FXML
    private Label label;
    
    @FXML
    private TextField birthText;

    @FXML
    private TextField nameText;

    @FXML
    private TextField yearText;

    @FXML
    private TextField countryText;

    @FXML
    private Button saveBtn;
    
    
    
    @FXML
    private void saveBtnHandle(){
        
        int yearN = Integer.parseInt(yearText.getText());
        
        if(nameText.getText().equals("") || 
           yearText.getText().equals("") ||
           birthText.getText().equals("") ||
           countryText.getText().equals("")){
            
            System.out.println("Töltsön ki minden mezőt!");
        }
        else if(yearN < 1989){
            showMessageDialog(null, "Hiba az évszám nem megfelelő!!");
        }
        else{
            try {
                FileWriter fw = new FileWriter("uj_dijazott.txt");
                fw.write("Év;Név;SzületesHalalozas;OrszagKód;\n" + 
                        yearText.getText() + ";" +
                        nameText.getText() + ";" +
                        birthText.getText() + ";" +
                        countryText.getText() + ";");
                fw.close();
                System.out.println("Fájl sikeresen mentésre került");
            } catch (IOException e) {
                System.out.println("Nem lehet beolvasni a fájlt");
                e.printStackTrace();
            }
        }
    }
     @Override
    public void initialize(URL url, ResourceBundle rb) {
    }
    }

   
        

     
